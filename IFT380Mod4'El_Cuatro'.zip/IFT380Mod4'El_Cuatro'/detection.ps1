#Team 'El Cuatro' SAM vulnerability check
#checks SAM folder for overly permissive ACLs
#built off of u/jadodd's detection script https://www.reddit.com/r/SCCM/comments/othe5d/cve202136934_serioussam_mitigation/

#variable to hold exit code
$res = "Compliant"

$errors = @()

#uses icals to query the target directory
$ACLs = $(icals C:\Windows\System32\config\SAM)

#Check for the BUILTIN\Users ACL entry
if($ACLs -match "BUILTIN\\Users:\(I\)\(RX\)") {
    $errors += "Overly permissive BUILTIN\Users ACL found."
}

#Check for the All App Packages ACL
if($ACLs -match "APPLICATION PACKAGE AUTHORITY\\ALL APPLICATION PACKAGES:\(I\)\(RX\)") {
    $errors += "Overly permissive BUILTIN\Users ACL found."
}

#Check for the All Restricted App Packages ACL
if($ACLs -match "APPLICATION PACKAGE AUTHORITY\\ALL RESTRICTED APPLICATION PACKAGES:\(I\)\(RX\)") {
    $errors += "Overly permissive ALL RESTRICTED APPLICATION PACKAGES ACL found."
}

if($errors -and $errors.Count -gt 0){
	$res = $errors -join "; "
}

return $res