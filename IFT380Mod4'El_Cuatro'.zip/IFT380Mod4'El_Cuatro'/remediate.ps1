#Team 'El Cuatro' script to delete existing shadow copies and create new ones
#Based on script by Git user 'JoranSlingerland' https://github.com/JoranSlingerland/CVE-2021-36934/blob/main/CVE-2021-36934.ps1

#variable for testing if statments
$vulnerable = $true

#gets existing shadowcopies
if ($vunerable) {
	function Get-ShadowVolumes {
        # Returns a list of volumeIDs and associated drive letters for drives containing shadow copies.
        $CurrentVolumes=Get-WmiObject Win32_ShadowStorage -Property Volume
        $AllVolumes=Get-WmiObject win32_volume
    
        $ShadowVolumes=[System.Collections.ArrayList]@()
        $pattern = 'Volume{.*?}'
        foreach ($volume in $CurrentVolumes){
            $Volume.volume -match $pattern | Out-Null
            $volumeID = $matches[0]
            if ($null -ne $volumeID){
                $DriveLetter = ($AllVolumes | where-object {$_.deviceid -match $volumeID}).driveletter
                $volumeinfo=[PSCustomObject]@{
                    VolumeID = $volumeID
                    DriveLetter = $DriveLetter
                }
                [void]$ShadowVolumes.add($volumeinfo)
            }
        }
        $ShadowVolumes
    }
    $ShadowVolumes = Get-ShadowVolumes
}

#change permissions and delete shadows
if ($vulnerable) {
    icacls c:\windows\system32\config\*.* /inheritance:e
    vssadmin delete shadows /quiet /all
}

#check permissions
if ($vulnerable -eq $true) {
    $checkPermissions = Get-Acl $env:windir\System32\Config
    if ($CheckPermissions.Access.IdentityReference -match $LocalUsersGroup.Name) {
        $permissionsSucces = $false
    }
    else {
        $permissionsSucces = $true
    }
}

#check shadow copy
if ($vulnerable -eq $true) {
    $checkShadow = Get-WmiObject Win32_ShadowStorage -Property Volume
    if ($null -eq $checkShadow) {
        $shadowSucces = $true
    }
    else {
        $shadowSucces = $false
    }
}

#check for fixed logic
if ($vulnerable -eq $true) {
    if ($permissionsSucces -eq $true -and $shadowSucces -eq $true) {
        $fixed = $true
    }
    else {
        $fixed = $false
    }
}
else {
    $fixed = 'Not applicable'
}

#creates a new shadow copy
if ($vulnerable -eq $true -and $shadowSucces -eq $true -and $permissionsSucces -eq $true) {
    foreach ($volume in $ShadowVolumes){
        wmic shadowcopy call create Volume="$($volume.driveletter)\"
    }
}

#output data
write-host "vulnerable: $vulnerable"
write-host "Fixed: $fixed"